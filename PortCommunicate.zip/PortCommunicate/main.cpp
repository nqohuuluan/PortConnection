#include <iostream>
#include <thread>
#include <chrono>
#include <fcntl.h>
#include <termios.h>
#include <unistd.h>

using namespace std;

void readData(int fd) {
    char buffer[256];
    while (true) {
        int n = read(fd, buffer, sizeof(buffer));
        if (n > 0) {
            buffer[n] = '\0';
            cout << "Read data: " << buffer << endl;
        }
        this_thread::sleep_for(chrono::milliseconds(100));
    }
}

void sendData(int fd) {
    char buffer[] = "Hello World!";
    while (true) {
        int n = write(fd, buffer, sizeof(buffer));
        if (n > 0) {
            cout << "Sent data: " << buffer << endl;
        }
        this_thread::sleep_for(chrono::milliseconds(100));
    }
}

int main() {
    int fd = open("/dev/ttyAMA0", O_RDWR | O_NOCTTY | O_NDELAY);
    if (fd == -1) {
        cout << "Error opening serial port" << endl;
        return -1;
    }

    struct termios options;
    tcgetattr(fd, &options);
    options.c_cflag = B9600 | CS8 | CLOCAL | CREAD;
    options.c_iflag = IGNPAR;
    options.c_oflag = 0;
    options.c_lflag = 0;
    tcflush(fd, TCIFLUSH);
    tcsetattr(fd, TCSANOW, &options);

    thread t1(readData, fd);
    thread t2(sendData, fd);

    t1.join();
    t2.join();

    close(fd);

    return 0;
}