

import serial
import threading

ser=serial.Serial('/dev/ttyACM0',9600)
ser.write_timeout=1

# define logPath "/home/kietla/Documents/PortCommunicate/data.log"

def write2file(a):
    with open('/home/kietla/Documents/PortCommunicate/data.log', 'w') as log:
        log.write(a)

def readPort():
    while True:
        readText = ser.readline();
        write2file(readText.decode('utf-8'))
        print(readText);
 
def sendData():
    while True:
        send_data=input("Send data: ")
        print("Send data success\n")
        ser.write(send_data.encode("utf-8"));
      
idle_state="1"
ser.write(idle_state.encode("utf-8"))

print("Starting program...")

t1 = threading.Thread(target=readPort)
t2 = threading.Thread(target=sendData)

t1.start()
t2.start()

t1.join()
t2.join()

print("Program ended")